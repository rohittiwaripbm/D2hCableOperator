﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class AddTransactions
    {
        public void RaiseComplain(int CustomerId, string Complains)
        {
            using(CableOperatorEntities RaiseComplain = new CableOperatorEntities())
            {
                RaiseComplain.RaiseComplain(CustomerId, Complains);
            }
        }

        public void ResolveComplain(int AgentId, DateTime Resolvedate,
            int ComplainId, string ExpenseType)
        {
            using(CableOperatorEntities ResolveComplain = new CableOperatorEntities()) 
            {
                ResolveComplain.ResolveComplain(AgentId,
                    Resolvedate, ComplainId, ExpenseType);
            }
        }


        public void AddPayment(int Customerid, int MonthId, int Year, bool IsPaid)
        {
            using(CableOperatorEntities Payment = new CableOperatorEntities())
            {
                Payment.AddPayment(Customerid, MonthId, Year, IsPaid);
            }
        }
    }
}
