﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class AdminMasterRolesinDatabase
    {
        public void AddCustomers(string CustomerName,int CustomerLocation,
            int CustomerPackage, string CustomerUsername, string CustomerPassword)
        {
            using(CableOperatorEntities c = new CableOperatorEntities()) 
            {
                c.AddCustomers(CustomerName,CustomerLocation,CustomerPackage,
                    CustomerUsername, CustomerPassword);
            }
        }

        public void AddAgent(string AgentName, string AgentUsername, string AgentPassword,
            int AgentLocation)
        {
            using(CableOperatorEntities Agent = new CableOperatorEntities()) 
            {
                Agent.AddAgents(AgentName,AgentUsername,AgentPassword,AgentLocation);
            }
        }

        public void AddPayment(int CustomerId, int MonthId, int Year,bool IsPaid)
        {
            using (CableOperatorEntities Payment = new CableOperatorEntities())
            {
                Payment.AddPayment(CustomerId, MonthId, Year, IsPaid);
            }
        }

        public void AddLocation(string Location)
        {
            using (CableOperatorEntities location = new CableOperatorEntities())
            {
                location.AddLocation(Location);
            }
        }
    }
}
