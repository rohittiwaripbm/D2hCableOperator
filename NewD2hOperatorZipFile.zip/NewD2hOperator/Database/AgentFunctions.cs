﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class AgentFunctions
    {
        public List<SingleAgentName_Result>GetAgent(string username)
        {
            using(CableOperatorEntities c = new CableOperatorEntities())
            {
                var list = c.SingleAgentName(username).ToList();
                return list;
            }
        }
        //public string GetAgentName(string UserName)
        //{
        //    using(CableOperatorEntities c = new CableOperatorEntities())
        //    {
        //        string name = "";
        //       var v =  c.SingleAgentName(UserName).ToList();
        //        foreach (var item in v)
        //        {
        //            name = item.Name;
        //        }
                
        //        return name;
        //    }
        //}

        //public int GetAgentId(string UserName)
        //{
        //    using (CableOperatorEntities c = new CableOperatorEntities())
        //    {
        //        int id = 0;
        //        var v = c.SingleAgentName(UserName).ToList();
        //        foreach (var item in v)
        //        {
        //            id = (int)item.AgentId;
        //        }
        //        return id;
        //    }
        //}
    }
}
