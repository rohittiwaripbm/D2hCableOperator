﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class CustomerFunctions
    {
        public  List<SingleCustomerName_Result> GetCustomer(string UserName)
        {
            using(CableOperatorEntities c = new CableOperatorEntities())
            {
                var v = c.SingleCustomerName(UserName).ToList();
                return v;
            }
        }
    }
}
