﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class DisplayLocations
    {
        public static List<DisplayLocations_Result> Display()
        {
            using(CableOperatorEntities Location = new CableOperatorEntities())
            {
                return Location.DisplayLocations().ToList();
                
            }
        }
        public static List<DisplayUnsignLocations_Result> UnsignedLocations()
        {
            using(CableOperatorEntities Location = new CableOperatorEntities())
            {
                return Location.DisplayUnsignLocations().ToList();
            }
        }
    }
}
