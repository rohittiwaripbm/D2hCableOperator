﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class GetAllUsers
    {
        public List<User> getUsers()
        {
            using(CableOperatorEntities c = new CableOperatorEntities()) 
            {
                var a  = c.Users.ToList();
                return a;
            }
        }
    }
}
