﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class GetSingleUsersFromUsername
    {
        public List<SingleCustomerName_Result> GetCustomerDetails(string Username)
        {
            using(CableOperatorEntities Customer = new CableOperatorEntities())
            {
                return Customer.SingleCustomerName(Username).ToList();
            }
        }

        public List<SingleAgentName_Result> GetAgentDetails(string Username)
        {
            using (CableOperatorEntities Customer = new CableOperatorEntities())
            {
                return Customer.SingleAgentName(Username).ToList();
            }
        }
    }
}
