﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class GetUserNames
    {
        public string GetName(string Username)
        {
            using(CableOperatorEntities Usernames = new CableOperatorEntities())
            {
                string name = null;
                var v = Usernames.CheckUserName(Username).ToList();
                foreach(var item in v)
                {
                    name = item;
                }
                return name;
            }
        }
    }
}
