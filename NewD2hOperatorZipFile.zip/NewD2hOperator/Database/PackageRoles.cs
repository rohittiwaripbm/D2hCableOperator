﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Database
{
    public class PackageRoles
    {
        public void AddNewPackage(string PackageName, decimal PackageCost)
        {
            using (CableOperatorEntities Package = new CableOperatorEntities())
            {
                Package.AddPackage(PackageName, PackageCost);
            }
        }

        public List<DisplayAllPackages_Result> DisplayAllPacage()
        {
            using(CableOperatorEntities Package = new CableOperatorEntities())
            {
                return Package.DisplayAllPackages().ToList();
            }
        }
    }
}
