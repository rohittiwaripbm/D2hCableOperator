﻿using Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewD2hOperator
{
    public class AdminRoles
    {
        public void DisplayActions()
        {
            Console.WriteLine("1. Add Master \n" +
                "2. Add Transactions \n" +
                "3. Show Reports \n" +
                "4. Exit \n");
            int AdminChoice = Validations.NumberValidation(Console.ReadLine());

            switch (AdminChoice)
            {
                case 1:
                    {
                        ShowMasterOptions();
                        break;
                    }
                case 2:
                    {
                        ShowTransactionOptions();
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("Show Reports Options");
                        break;
                    }
                case 4:
                    {
                        Console.WriteLine("Exit");
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Invalid Input ");
                        DisplayActions();
                        break;
                    }
            }
            Console.WriteLine();
            DisplayActions();
        }

        public void ShowMasterOptions()
        {
            Console.WriteLine("1. Add Customer \n" +
                "2. Add Agent \n" +
                "3. Add Location \n" +
                "4. Add Package \n ");
            int AdminChoice = Validations.NumberValidation(Console.ReadLine());

            switch (AdminChoice)
            {
                case 1:
                    {
                        MasterRoles Customer = new MasterRoles();
                        Customer.AddCustomers();
                        break;
                    }
                case 2:
                    {
                        MasterRoles Agent = new MasterRoles();
                        Agent.AddAgents();
                        break;
                    }
                case 3:
                    {
                        MasterRoles Location = new MasterRoles();
                        Location.AddLocations();
                        break;
                    }
                case 4:
                    {
                        MasterRoles Package = new MasterRoles();
                        Package.AddPackage();
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Please Enter a Valid input");
                        ShowMasterOptions();
                        break;
                    }
            }
        }

        public void ShowTransactionOptions()
        {
            Console.WriteLine("1. Raise Complain \n" +
                "2. Resolve Complain \n" +
                "3. Add Payment \n");
            int AdminChoice = Validations.NumberValidation(Console.ReadLine());
            switch (AdminChoice)
            {
                case 1:
                    {
                        Console.WriteLine("Raise Complain");
                        AdminRaiseComplain();


                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Resolve Complain");
                        AdminResolveComplain();
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("Add Payments");
                        Addpayments();
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Please enter a valid input");
                        ShowTransactionOptions();
                        break;
                    }
            }
        }

        public void AdminRaiseComplain()
        {
            //Can Display all customers or can display with search
            Console.WriteLine("Enter Customer Id");
            int CustomerId = Validations.NumberValidation(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter Complains, If Multiple Complains use ',' ");
            string Complains = Validations.MakeNametoLower(Console.ReadLine());
            Console.WriteLine();
            TransactionRoles Complain = new TransactionRoles();
            Complain.RaiseComplain(CustomerId, Complains);
        }

        public void AdminResolveComplain()
        {
            //int AgentId, DateTime Resolvedate, int ComplainId,
            //decimal Cost, int ExpenseType

            Console.WriteLine("Enter Agent Id");
            int AgentId = Validations.NumberValidation(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter Date or leave Empty for todays date");
            DateTime ResolveDate = Validations.SetDatetime(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter ComplainId");
            int ComplainId = Validations.NumberValidation(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter Expense Type and Cost, like 1:200, 2:300");
            string Expenses = Console.ReadLine();

            AddTransactions Complain = new AddTransactions();
            Complain.ResolveComplain(AgentId,ResolveDate, ComplainId,Expenses);
        }

        public void Addpayments()
        {
            // int CustomerId, int MonthId, int Year, bool IsPaid
            
            Console.WriteLine("Enter CustomerID");
            int CustomerId = Validations.NumberValidation(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter Month Id");
            int MonthId = Validations.NumberValidation(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter Year Year or leave Empty for Current year");
            int Year = Validations.YearValidation(Console.ReadLine());
            TransactionRoles payment = new TransactionRoles();
            Console.WriteLine();
            Console.WriteLine("Payment Status 1 for paid 0/blank for unpaid");
            bool IsPaid = Validations.IsValid(Console.ReadLine());
            payment.AddPayments(CustomerId, MonthId, Year,IsPaid);
        }

    }
}
