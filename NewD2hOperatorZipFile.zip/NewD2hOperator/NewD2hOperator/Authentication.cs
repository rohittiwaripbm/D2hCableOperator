﻿using Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewD2hOperator
{
    public class Authentication
    {
        public static int CheckUsers(string Username, string Password)
        {
           
            GetAllUsers s = new GetAllUsers();
            var v = s.getUsers();
            int RolesId;
            bool UserPresent = false;
            foreach (var item in v)
            {
                //Console.WriteLine(item.Username+ " " + item.Password);
                if (Username == item.UserName && Password == item.Password)
                {
                    RolesId = (int)item.RolesId;
                    if (RolesId == 1)
                    {
                        //Console.WriteLine("Admin Login");
                        return 1;
                    }
                    else if (RolesId == 2)
                    {
                        
                        return 2;
                    }
                    else
                    {
                        
                        return 3;
                    }
                    //if logged in then return rolesid

                }

            }
            if (!UserPresent)
            {
                //Console.WriteLine("Incorrect Username or password");
                
                return 4;

            }
            return 0;

        }
    }
}
