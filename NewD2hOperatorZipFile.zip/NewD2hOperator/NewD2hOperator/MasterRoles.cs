﻿using Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewD2hOperator
{
    public class MasterRoles
    {



        public static List<string> CommonDetails()
        {
            List<string> list = new List<string>();
            Console.WriteLine("Enter  Name");
            string Name = Validations.MakeNametoLower(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("Enter  UserName");
            string Username = Validations.UserNameChecker(Console.ReadLine()).ToLower();
            Console.WriteLine();
            Console.WriteLine("Set Password");
            string Password = Console.ReadLine();
            list.Add(Name);
            list.Add(Username);
            list.Add(Password);
            return list;
        }

        public void AddCustomers()
        {
            int LatestLocationID, LocationId;
            var Location = DisplayLocations.Display();
            List<string> list = MasterRoles.CommonDetails();
            Console.WriteLine();
            foreach (var item in Location)
            {
                Console.WriteLine(item.Id + ".  " + item.Location);
                Console.WriteLine();
            }
            Console.WriteLine("Enter 'y' to add New Location ");
            string AddLocation = Console.ReadLine();
            if(AddLocation == "y" || AddLocation == "Y")
            {
                AddLocations();
                var NewLocation = DisplayLocations.Display();
                LocationId = NewLocation.LastOrDefault().Id;
                
            }
            //Logic to add new location or call location add method
            else
            {
                Console.WriteLine("Enter Location");
                LocationId = Validations.NumberValidation(Console.ReadLine());
            }
            
            Console.WriteLine();
            Console.WriteLine("Enter Package");
            int PackageId = Validations.NumberValidation(Console.ReadLine());
            Console.WriteLine();
            AdminMasterRolesinDatabase Add = new AdminMasterRolesinDatabase();
            Add.AddCustomers(list[0], LocationId, PackageId, list[1], list[2]);
            Console.WriteLine("Customer Added Successfully");

            //show available locations..
            //Add Validation
        }//Have to add New Location Logic & display pacakage
        public void AddAgents()
        {
            List<string> list = MasterRoles.CommonDetails();
            Console.WriteLine();
            var Locations = DisplayLocations.UnsignedLocations();
            Console.WriteLine("---------------------------------------");
            foreach (var item in Locations)
            {
                Console.WriteLine(item.Id + ".  " + item.Location);
                Console.WriteLine();
            }
            Console.WriteLine("---------------------------------------");
            Console.WriteLine();
            Console.WriteLine("Enter Location");
            int LocationId = Validations.NumberValidation(Console.ReadLine());

            AdminMasterRolesinDatabase Add = new AdminMasterRolesinDatabase();
            Add.AddAgent(list[0], list[1], list[2], LocationId);
            Console.WriteLine();
            Console.WriteLine("Agent Added Successfully");

        }

        public void AddPackage()
        {
            Console.WriteLine("Enter Package Name");
            string Name = Validations.MakeNametoLower(Console.ReadLine());
            
            Console.WriteLine();
            Console.WriteLine("Enter Package Cost");
            decimal Cost = Validations.CostChecker(Console.ReadLine());

            PackageRoles AddPackage = new PackageRoles();
            AddPackage.AddNewPackage(Name, Cost);
            Console.WriteLine();
            Console.WriteLine("Pacakage Added Successfully");
        }//Display all pakages

        public void AddLocations()
        {
            Console.WriteLine("Enter Location Name");
            string Name = Validations.MakeNametoLower(Console.ReadLine());
            
            Console.WriteLine();
            AdminMasterRolesinDatabase Locations = new AdminMasterRolesinDatabase();
            Locations.AddLocation(Name);
        }
    }
}
