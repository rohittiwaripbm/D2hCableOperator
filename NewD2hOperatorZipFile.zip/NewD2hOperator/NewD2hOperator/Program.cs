﻿using Database;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewD2hOperator
{
    internal class Program
    {
        
        public static void CheckUser()
        {
            GetSingleUsersFromUsername Users = new GetSingleUsersFromUsername();
            
            Console.WriteLine("Enter User name");
            string Username = Console.ReadLine();
            Console.WriteLine("Enter Password");
            string Password = Console.ReadLine();
 
            int Result = Authentication.CheckUsers(Username,Password);
            if (Result == 1)
            {
                Console.WriteLine("Welcome Admin");
                AdminRoles role = new AdminRoles();
                role.DisplayActions();
            }
            else if(Result == 2)
            {
                string Name = "";
                var Customerlist = Users.GetCustomerDetails(Username);
                foreach (var item in Customerlist)
                {
                    Name = item.Name;
                }
                Console.WriteLine("Welcome : " + Name);

            }
            else if (Result == 3)
            {
                string Name = "";
                var Agentlist = Users.GetAgentDetails(Username);
                foreach (var item in Agentlist)
                {
                    Name = item.Name;
                }
                Console.WriteLine("Welcome : " + Name);
            }
            else
            {
                Console.WriteLine("Incorrect Username and Password");
                CheckUser();
            }
        }
        static void Main(string[] args)
        {
            //install EntityFramework
            //connction from app Config
                CheckUser();
            
            
            Console.ReadLine();
        }
    }
}
