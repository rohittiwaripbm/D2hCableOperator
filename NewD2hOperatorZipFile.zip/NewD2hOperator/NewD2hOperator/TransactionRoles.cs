﻿using Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewD2hOperator
{
    public class TransactionRoles
    {

        public void RaiseComplain(int CustomerId, string Complains)
        {
            //if admin raise complain we have to go to AdminRoles in D2h
            AddTransactions Complain = new AddTransactions();
            Complain.RaiseComplain(CustomerId, Complains);
            //Have to Show complain raise for which customer
            Console.WriteLine("Complain Raised Successfully");
        }

        public void ResolveComplain(int AgentId, DateTime Resolvedate, int ComplainId,
             string ExpenseType)
        {
            //Have to Display All Agents
            AddTransactions Complain = new AddTransactions();
            Complain.ResolveComplain(AgentId, Resolvedate,ComplainId, ExpenseType);
            Console.WriteLine();
            Console.WriteLine("Complain Resolved Successfully");
        }

        public void AddPayments(int CustomerId, int MonthId, int Year, bool IsPaid)
        {
            AddTransactions Payment = new AddTransactions();
            Payment.AddPayment(CustomerId, MonthId, Year, IsPaid);
            Console.WriteLine();
            Console.WriteLine("Payment added for this customer Successfully");
        }
    }
}
