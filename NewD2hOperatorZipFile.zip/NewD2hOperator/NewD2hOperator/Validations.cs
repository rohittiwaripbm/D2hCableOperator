﻿using Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewD2hOperator
{
    public class Validations
    {
        public static int NumberValidation(string Number)
        {
            Number = Number.Trim();
            bool NumberChecker = int.TryParse(Number, out int Result);
            if (NumberChecker)
            {
                return Result;
            }
            else
            {
                Console.WriteLine("Please Enter a Valid Option");
                string NewNumber = Console.ReadLine();
                return NumberValidation(NewNumber);
            }
        }

        public static string UserNameChecker(string UserName)
        {
            GetUserNames Users= new GetUserNames();

            string Checkusername = Users.GetName(UserName);
            
            //return Checkusername;
            
                if (string.IsNullOrEmpty(Checkusername))
                {
                return UserName;
                }
                else
                    {
                    Console.WriteLine("UserName already in Use");
                    string name = Console.ReadLine();
                    return UserNameChecker(name);
                    }
            

        }

        public static decimal CostChecker(string Cost)
        {
            bool Check = decimal.TryParse(Cost, out decimal Result);
            if (!Check)
            {
                Console.WriteLine("Please Enter a valid input");
                string newcost = Console.ReadLine();
                return CostChecker(newcost);
            }
            else
            {
                return Result;
            }
        }

        public static string MakeNametoLower(string Name) 
        {
            Name = Name.Trim();
            return (Name[0].ToString().ToUpper())
                + (Name.Substring(1, Name.Length - 1)).ToLower();
        }

        public static DateTime SetDatetime(string Date)
        {
            if(string.IsNullOrEmpty(Date))
            {
                return DateTime.Now;
            }
            else
            {
                Date = Date.Trim();
                    bool check = DateTime.TryParse(Date, out DateTime result);
                    if (check)
                    {
                        return result;
                    }
                else
                {
                    Console.WriteLine("Invalid Date ");
                    string NewDate = Console.ReadLine();
                    return SetDatetime(NewDate);
                }
                
            }
        }

        public static int YearValidation(string Year)
        {
            if(string.IsNullOrEmpty(Year))
            {
                return DateTime.Now.Year;
            }
            else
            {
                int NewYear = Validations.NumberValidation(Year);
                return NewYear;
            }
        }

        public static bool IsValid(string Status)
        {
            if(string.IsNullOrEmpty(Status))
            {
                return false;
            }
            else
            {
                int number = Validations.NumberValidation(Status);
                if(number >= 0 && number<=1) 
                {
                    if (number == 0) 
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    Console.WriteLine("Plese Enter a Valid input");
                    string NewStatus = Console.ReadLine();
                    return IsValid(NewStatus);
                }
            }

        }
    }
}
